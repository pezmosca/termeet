import sqlite3

con_bd = sqlite3.connect("users.db")
con_bd.row_factory = sqlite3.Row
cursor_agenda = con_bd.cursor()
username = ("pezmosca", )
cursor_agenda.execute("SELECT * FROM logins WHERE username=?", username)
registro = cursor_agenda.fetchone()
print registro["username"]
