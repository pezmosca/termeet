from __future__ import unicode_literals

__title__ = 'python-gssapi'
__author__ = 'Hugh Cole-Baker and contributors'
__version__ = '0.6.5pre'

__license__ = 'The MIT License (MIT)'
__copyright__ = 'Copyright 2014 {0}'.format(__author__)
