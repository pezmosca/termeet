TODO
====

* ``gss_add_cred`` support?
* Add support for useful GSSAPI / krb5 extensions, e.g. storing delegated credentials
