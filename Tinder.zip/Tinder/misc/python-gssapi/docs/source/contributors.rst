Contributors
============

This page lists the contributors to this project,
in alphabetic order and is generated automatically
from the Git changelog.

.. program-output:: git log --format='%aN' | sort -u
    :shell:
