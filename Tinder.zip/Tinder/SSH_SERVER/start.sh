
export AUTH_DB_HOST=termeet.cliv758zqmn7.eu-west-1.rds.amazonaws.com
export AUTH_DB_USERNAME=termeet
export AUTH_DB_PASSWORD=termeet1234
export AUTH_DB_NAME=MasterTermeet


python demo_server.py
