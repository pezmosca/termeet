class Profile:
    userID = 3
    nick = "Hulio"
    fullName = "Hulio Biffle Palo Alto"
    interests = "#Baguete"
    description = "Olala"
    age = 47
    gender = "Male"
    searching = 3
    work = "Baguete maker"
    study = "Your body"
    urlFoto = "randomurl"
    correo = "hulioQuiereTuBody@fib.upc.edu"

def __init__(self,nick,fullname,interests,description,age,gender,searching,work,study):
    self.nick = nick
    self.fullName = fullname
    self.interests = interests
    self.description = description
    self.age= age
    self.gender = gender
    self.searching = searching
    self.work = work
    self.study =study



def __init__(self):
        self.data = []


pass
